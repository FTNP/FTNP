const PROFANITY_LIST = [
  "badword1",
  "badword2",
  // Add more words as needed
];

export function containsProfanity(text: string): boolean {
  const lowercaseText = text.toLowerCase();
  return PROFANITY_LIST.some(word => lowercaseText.includes(word));
}
