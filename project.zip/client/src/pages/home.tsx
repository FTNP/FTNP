import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion, AnimatePresence } from "framer-motion";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { insertMessageSchema, type Message, moods } from "@shared/schema";
import { containsProfanity } from "@/lib/profanity";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Send, MessageSquare, Eye } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function Home() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm({
    resolver: zodResolver(
      insertMessageSchema.refine(
        (data) => !containsProfanity(data.content),
        { message: "Message contains inappropriate content" }
      )
    ),
    defaultValues: {
      content: "",
      mood: undefined,
    },
  });

  const messageMutation = useMutation({
    mutationFn: async (data: { content: string; mood?: string }) => {
      const res = await apiRequest("POST", "/api/messages", data);
      return res.json();
    },
    onSuccess: () => {
      form.reset();
      toast({
        title: "Message sent!",
        description: "Your message has been saved for a future visitor.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/messages/random"] });
      queryClient.invalidateQueries({ queryKey: ["/api/messages/stats"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const { data: receivedMessage, isLoading, refetch } = useQuery<Message>({
    queryKey: ["/api/messages/random"],
  });

  const { data: stats } = useQuery<{ total: number; totalViews: number }>({
    queryKey: ["/api/messages/stats"],
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/50 p-4">
      <div className="max-w-2xl mx-auto space-y-8 pt-8">
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold bg-gradient-to-b from-foreground to-foreground/70 bg-clip-text text-transparent tracking-tight">
            For The Next Person
          </h1>
          <p className="text-muted-foreground text-lg">
            And what is one message for the next person?
          </p>
          {stats && (
            <div className="flex justify-center gap-8 mt-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4" />
                <span>{stats.total} messages sent</span>
              </div>
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4" />
                <span>{stats.totalViews} total views</span>
              </div>
            </div>
          )}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={receivedMessage?.id || "loading"}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="shadow-lg hover:shadow-xl transition-all duration-300 border-primary/10">
              <CardContent className="pt-6 space-y-4">
                {isLoading ? (
                  <div className="h-24 flex items-center justify-center">
                    <div className="animate-pulse text-muted-foreground">
                      Finding a message...
                    </div>
                  </div>
                ) : receivedMessage ? (
                  <div className="space-y-4">
                    <div className="flex justify-between items-start">
                      <MessageSquare className="w-8 h-8 text-primary animate-in fade-in-50" />
                      {receivedMessage.mood && (
                        <span className="text-sm text-muted-foreground">
                          Mood: {receivedMessage.mood}
                        </span>
                      )}
                    </div>
                    <p className="text-lg leading-relaxed">{receivedMessage.content}</p>
                    <div className="text-sm text-muted-foreground text-right">
                      Viewed {receivedMessage.viewCount} times
                    </div>
                  </div>
                ) : (
                  <div className="h-24 flex items-center justify-center text-muted-foreground">
                    No messages available
                  </div>
                )}
                <Button
                  onClick={() => refetch()}
                  variant="outline"
                  className="w-full hover:bg-primary/5 transition-colors border-primary/20"
                  disabled={isLoading}
                >
                  Get Another Message
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>

        <Form {...form}>
          <form
            onSubmit={form.handleSubmit((data) => messageMutation.mutate(data))}
            className="space-y-4"
          >
            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Textarea
                      placeholder="Write your message for the next person..."
                      className="h-32 resize-none focus:ring-primary/20 border-primary/20"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="mood"
              render={({ field }) => (
                <FormItem>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="w-full border-primary/20">
                        <SelectValue placeholder="Select a mood (optional)" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {moods.map((mood) => (
                        <SelectItem key={mood} value={mood}>
                          {mood}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button
              type="submit"
              className="w-full bg-primary hover:bg-primary/90 transition-opacity"
              disabled={messageMutation.isPending}
            >
              <Send className="w-4 h-4 mr-2" />
              Send Message
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
}