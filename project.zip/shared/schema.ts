import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  isRead: text("is_read").default("false"),
  viewCount: integer("view_count").default(0),
  mood: text("mood"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const moods = [
  "Happy",
  "Reflective",
  "Hopeful",
  "Grateful",
  "Inspired",
  "Calm",
] as const;

export const insertMessageSchema = createInsertSchema(messages)
  .pick({ content: true, mood: true })
  .extend({
    content: z
      .string()
      .min(1, "Message cannot be empty")
      .max(280, "Message must be less than 280 characters"),
    mood: z.enum(moods).optional(),
  });

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;