import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertMessageSchema } from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express) {
  app.post("/api/messages", async (req, res) => {
    try {
      const data = insertMessageSchema.parse(req.body);
      const message = await storage.createMessage(data);
      res.json(message);
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ message: error.errors[0].message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get("/api/messages/random", async (req, res) => {
    const message = await storage.getRandomUnreadMessage();
    if (!message) {
      res.status(404).json({ message: "No messages available" });
      return;
    }

    await storage.markMessageAsRead(message.id);
    await storage.incrementViewCount(message.id);
    res.json(message);
  });

  app.get("/api/messages/stats", async (req, res) => {
    const stats = await storage.getMessageStats();
    res.json(stats);
  });

  return createServer(app);
}