import { messages, type Message, type InsertMessage } from "@shared/schema";

export interface IStorage {
  createMessage(message: InsertMessage): Promise<Message>;
  getRandomUnreadMessage(): Promise<Message | undefined>;
  markMessageAsRead(id: number): Promise<void>;
  incrementViewCount(id: number): Promise<void>;
  getMessageStats(): Promise<{ total: number; totalViews: number }>;
}

export class MemStorage implements IStorage {
  private messages: Map<number, Message>;
  private currentId: number;
  private lastReturnedId: number | null;

  constructor() {
    this.messages = new Map();
    this.currentId = 1;
    this.lastReturnedId = null;
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.currentId++;
    const message: Message = {
      id,
      content: insertMessage.content,
      mood: insertMessage.mood || null,
      isRead: "false",
      viewCount: 0,
      createdAt: new Date(),
    };
    this.messages.set(id, message);
    return message;
  }

  async getRandomUnreadMessage(): Promise<Message | undefined> {
    const allMessages = Array.from(this.messages.values());
    if (allMessages.length === 0) return undefined;

    // If we only have one message, return it
    if (allMessages.length === 1) {
      this.lastReturnedId = allMessages[0].id;
      return allMessages[0];
    }

    // Get a different message than the last one if possible
    let randomMessage: Message;
    do {
      const randomIndex = Math.floor(Math.random() * allMessages.length);
      randomMessage = allMessages[randomIndex];
    } while (
      this.lastReturnedId !== null && 
      randomMessage.id === this.lastReturnedId && 
      allMessages.length > 1
    );

    this.lastReturnedId = randomMessage.id;
    return randomMessage;
  }

  async markMessageAsRead(id: number): Promise<void> {
    const message = this.messages.get(id);
    if (message) {
      message.isRead = "true";
      this.messages.set(id, message);
    }
  }

  async incrementViewCount(id: number): Promise<void> {
    const message = this.messages.get(id);
    if (message) {
      message.viewCount = (message.viewCount || 0) + 1;
      this.messages.set(id, message);
    }
  }

  async getMessageStats(): Promise<{ total: number; totalViews: number }> {
    const messages = Array.from(this.messages.values());
    const totalViews = messages.reduce((sum, msg) => sum + (msg.viewCount || 0), 0);
    return {
      total: messages.length,
      totalViews,
    };
  }
}

export const storage = new MemStorage();